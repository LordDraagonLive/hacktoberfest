var quotes = ['Hello World!', 'hello world', 'HELLO WORLD!', 'Heeelllooo Wooorrrlldd', 'Hello world', 'Hello...World', 'Hello #@%$ World', 'Hello world?', 'Hello hello hello world world world']

function displayQuotes(){
var i = Math.floor(Math.random() * 9);
document.getElementById("main-quote").innerHTML = quotes[i];
}